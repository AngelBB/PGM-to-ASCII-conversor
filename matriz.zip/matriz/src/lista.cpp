#include <string>
#include <fstream>
#include "lista.h"
#include <iostream>

using namespace std;

//Constructor por defecto
Lista::Lista(){
	cabecera=0;
}
   
//Constructor por param.
Lista::Lista(string valor){
	if(valor.size()!=0){
		cabecera=new Celda;
		cabecera->datos=valor;
		cabecera->siguiente=0;
	}
}
	
//Constructor por copia
Lista::Lista(const Lista &otra_lista){
	//cabecera=new Celda;
	int tamanio = otra_lista.longitud();
	for(int i=0;i<tamanio;i++){
		this->insertar((otra_lista.getCelda(i)));
	}	
	
}

//Sobrecarga del operador =
Lista& Lista::operator=(const Lista &otra_lista){
	if(this!=&otra_lista){//Comprueba que no se esté intentando igualar un objeto a sí mismo
		destruir();
		//cabecera=new Celda;
		for(int i=0;i<otra_lista.longitud();i++){
			this->insertar((otra_lista.getCelda(i)));
		}	
	}
	return *this;
}


//Sobrecaga del operador +
Lista Lista::operator+(const string cadena)const{
	Lista aux;
	int tamanio=longitud();
	//Primero asignamos todas las cadenas propias de nuestro objeto al nuevo
	for(int i=0;i<tamanio;i++){
		aux.insertar(getCelda(i));
	}
	//Aniadimos al final del nuevo objeto la cadena que tenemos de parametro.
	aux.insertar(cadena);
	
	return aux;
}




//Destructor
Lista::~Lista(void){
	destruir();
}


//Destructor artesanal
void Lista::destruir(){
	if(cabecera!=0){
		Celda * celda_actual=cabecera;
		while(celda_actual!=0){
				Celda * siguiente=celda_actual->siguiente;
				delete celda_actual;
				celda_actual=siguiente;		
		}
		
		cabecera=0;
		
	}
}


void Lista::insertar(string valor){
		if(valor!=" "){
			Celda * nueva_celda=new Celda;
			nueva_celda->datos=valor;
			nueva_celda->siguiente=0;/*Ponemos null para indicar que 
			es la ultima celda que se ha insertado*/
			
			if(cabecera==0){
					cabecera=nueva_celda;
			}else{
					Celda * celda_actual=cabecera;//Hacemos una copia
					
					/*Vamos comprobando celda a celda a traves del puntero siguiente, 
					 * si es nulo o no lo es. Si no es nulo significa que ya hay una celda con datos en memoria,
					 * de lo contrario significa que esta vacia y 
					 * podemos insertar ahí el nuevo dato.*/
					 
					while(celda_actual->siguiente!=0){//Cuando sea null saldremos
						celda_actual=celda_actual->siguiente;/*Vamos almacenando 
						el puntero a memoria de la siguiente celda */
					}
					celda_actual->siguiente=nueva_celda;/*Insertamos la 
					nueva celda en la posicion NULL o vacia*/
			}
			
		}
}

string Lista::getCelda(int pos) const{
	Celda * celda_actual=cabecera;
	string cadena=" ";//Por defecto devolvemos cadena vacia
	int cont=0;
	int tamanio=longitud();

	if(pos<=tamanio){//Comprobamos que pos no excenda del numero de celdas creadas
		while(celda_actual!=0 && cont<=pos){
			cadena=celda_actual->datos;
			celda_actual=celda_actual->siguiente;//Punt. hacia la siguiente celda
			cont++;
		}
	}
		
	return cadena;

}

int Lista::longitud() const{
	Celda * celda_actual=cabecera;
	int nceldas=0;
	while(celda_actual!=0){
		nceldas++;
		celda_actual=celda_actual->siguiente;//Punt. hacia la siguiente celda
	}
	return nceldas;

}



/**
 * @brief Construye una lista de celdas enlazadas a partir de la informacion 
 * contenida en un fichero.
 * @param nombreFichero ruta del fichero de texto con el contenido de las datoss
 * a insertar en la lista
 * @retval true si ha tenido éxito en la lectura y el formato es el correcto
 * @retval false si se ha producido algún error en la lectura 
 * 
 * Lee desde disco los elementos almacenados en @a nombreFichero y los guarda 
 * en la lista. La función debe asegurarse de que la estructura sigue un patron 
 * determinado, y se ha de crear la lista con el numero de elementos que contenga. 
 */
bool Lista::leerLista(const char nombrefichero[]){
	ifstream fin;
	fin.open(nombrefichero);
	if(!fin){
		return false;
	}else{
		string grises;
		int lineas;
		getline(fin,grises); //la primera linea se ignora
		fin >> lineas; //leo el numero de datos de grises
		getline(fin,grises); //leer salto de linea
		if (!fin){
			return false;
		}else {
			int i = 0;
			getline(fin,grises); //leer cadena de caracteres
			while ((i < lineas)&&(fin)){
				if (grises != ""){
					insertar(grises);
					i++;
				}
				getline(fin,grises); //leer cadena de caracteres
			}
		}
		fin.close();
	}
	return true;
}
