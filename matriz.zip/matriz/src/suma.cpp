/**
  * @file 
  * @brief Realiza la concatenacion de dos imagenes
  **/

#include<iostream>
#include "imagen.h"

using namespace std;


int main(int argc, char *argv[]){
  
	if(argc == 5){
	
		Imagen img1,img2,img_resultado;
				
		bool ok1,ok2,ok3=false;
			
		// Leer la imagenes desde ficheros
		ok1=img1.leerImagen(argv[1]);
		ok2=img2.leerImagen(argv[2]);
		
		if(!ok1){
			cerr<<"El primer parametro no es valido !"<<endl;
			cerr<<"Introduce bien el nombre de la primera imagen de entrada !"<<endl;
				return 1;
		}
		
		if(!ok2){
			cerr<<"El segundo parametro no es valido !"<<endl;
			cerr<<"Introduce bien el nombre de la segunda imagen de entrada !"<<endl;
				return 1;
		}
		
					
		if(*argv[3]==' '){		
			cerr<<"El tercer parametro no es valido !"<<endl;
			cerr<<"Introduce bien el nombre de la imagen de salida !"<<endl;
				return 1;
		}
				
		
		//Comprobamos el parametro de formato	
		if(*argv[4]!='t' && *argv[4]!='b'){
			cerr<<"El cuarto parametro no es valido !"<<endl;
			cerr<<"No has introducido bien el flag. Usa: (b)Binario (t)Texto !"<<endl;
			return 1;
		}else{
			ok3=true;	
		}


		if(ok1 && ok2 && ok3){
			img_resultado=img1+img2;	
			bool estado=false;					
				//Comprobamos el parametro de formato	
				if(*argv[4]=='t'){
					estado=img_resultado.escribirImagen(argv[3], false);
				}else if(*argv[4]=='b'){
					estado=img_resultado.escribirImagen(argv[3], true);
				}
			
			if(estado){
				cout<<"Exito en la concatenacion de imagenes."<<endl;
				cout<<"Imagen creada correctamente!"<<endl;
			
			}else{
				cerr <<"Se ha producido un error en la creacion de la imagen concatenada"<<endl;
			}
		}


	}else{
		cerr<<"Introduce el numero correcto de parametros !"<<endl;
	}


		
    return 0;
	
}
