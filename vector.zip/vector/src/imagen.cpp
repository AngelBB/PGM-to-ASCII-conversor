/**
  * @file 
  * @brief Fichero que permite la creacion de la imagen , concatenacion y asignacion.
  * Tambien es el encargado para la transformacion a imagen ASCII.
  */
#include "imagen.h"
#include "pgm.h"
#include "byte.h"
#include "lista.h"
#include <iostream>
#include <string>
#include <cstring>
#include <fstream>


using namespace std;
typedef unsigned char byte;


//Construye una imagen vacia(0 filas, 0 columnas)
Imagen::Imagen(){
	nfilas=0;
	ncolumnas=0;
	datos=0;
}


//Construye una imagen negra de tamanio filas x columnas
Imagen::Imagen(int filas,int columnas){
		datos=0;		
		crear(filas,columnas);
}


//Constructor por copia
Imagen::Imagen (const Imagen &img){
	datos=0;		
	crear(img.nfilas,img.ncolumnas);		
	copiarVector(img);
}


//sobrecarga de op: =
Imagen& Imagen::operator=(const Imagen &img){
	if(this != &img){
		crear(img.nfilas,img.ncolumnas);
		copiarVector(img);
	}
	
	return *this;
}


//sobrecarga de op. + para concatenar imagenes
Imagen Imagen::operator+(const Imagen &img){
		int max_fil,max_col;
	
		
if(img.nfilas >= this->nfilas){
	max_fil=img.nfilas;

}else if(img.nfilas <= this->nfilas){
	max_fil=this->nfilas;
}
max_col=((this->ncolumnas)+(img.ncolumnas));

Imagen nueva_img(max_fil,max_col);

int pos=0,posImg1=0,posImg2=0,j=0;

	
	//Recorremos la nueva imagen unida
	for(int i=0;i<max_fil;i++){
		j=0;
			//Imagen1
			for(int k=0;k<(this->ncolumnas) && (pos<(max_col*max_fil)) && (j < max_col);k++){
				posImg1=((i*this->ncolumnas)+k);
				if(posImg1<((this->ncolumnas)*this->nfilas)){
					nueva_img.setPos(pos,this->datos[posImg1]);
				}
				pos++;
				j++;
			}
			
			//Imagen2
			for(int l=0;l<(img.ncolumnas) && (pos < (max_col*max_fil)) && (j < max_col);l++){
				posImg2=((i*img.ncolumnas)+l);
				if(posImg2<(img.ncolumnas*img.nfilas)){
					nueva_img.setPos(pos,img.datos[posImg2]);
				}
				pos++;
				j++;
			}
	}
	
	return nueva_img;
}
	


//Crea una imagen negra de tamanio filas x columnas
void Imagen::crear(int filas,int columnas){
	destruir();
	nfilas=filas;
	ncolumnas=columnas;
	datos=new byte[(nfilas*ncolumnas)];
	//Ponemos todos los elementos a 0, es decir en negro
	for(int i=0;i<(nfilas*ncolumnas);i++){
		apagar(datos[i]);
	}
	
}

//Destructor
Imagen::~Imagen(){
	destruir();
}

//Destructor artesanal
void Imagen::destruir(){
	if(datos!=0){
		nfilas=0;
		ncolumnas=0;
		delete [] datos;
	}
}
void Imagen::copiarVector(const Imagen &img){
	//Copiamos posicion a poscion del objeto pasado al nuevo
	for(int i=0;i<(nfilas*ncolumnas);i++){
		this->datos[i]=img.datos[i];
	}
}

//Devuelve el numero de filas de la imagen
int Imagen::filas(){
	return nfilas;	
}


//Devuelve el numero de columnas de la imagen
int Imagen::columnas(){
		return ncolumnas;
}


//Asigna el valor v a la posicion(x,y) de la imagen
void Imagen::set(int y,int x,byte v){
	int pos=(y*ncolumnas)+x;
	if(pos < (nfilas*ncolumnas)){
		datos[pos]=v;
	}

}


//Devuelve el valor de la posicion(x,y)de la imagen
byte Imagen::get(int y,int x){
int pos=(y*ncolumnas)+x;
	if(pos < (nfilas*ncolumnas)){
		return datos[pos];
	}	
	return 0;
}


//Asigna el valor v a la posicion i de la imagen considerada como vector
void Imagen::setPos(int i,byte v){
	if(i<(nfilas*ncolumnas)){
		datos[i]=v;
	}
}


//Devuelve el valor de la posicion i de la imagen considerada como vector
byte Imagen::getPos(int i){
	if(i<(nfilas*ncolumnas)){
		return datos[i];
	}
	
	return 0;
}


bool Imagen::leerImagen(const char nombreFichero[]){
	bool estado=false;
	TipoImagen tipo=infoPGM(nombreFichero, nfilas, ncolumnas);
	
		if(tipo==IMG_PGM_BINARIO){
			crear(nfilas,ncolumnas);
			estado=leerPGMBinario (nombreFichero, datos, nfilas, ncolumnas);
		}else if(tipo==IMG_PGM_TEXTO){
			crear(nfilas,ncolumnas);
			estado=leerPGMTexto (nombreFichero, datos, nfilas, ncolumnas);
		}
	
	return estado;
}


bool Imagen::escribirImagen(const char nombreFichero[],bool esBinario){
	
	bool estado=false;
	
	if(!esBinario){
		estado=escribirPGMTexto (nombreFichero, datos, nfilas, ncolumnas);		
	}else{
		estado=escribirPGMBinario (nombreFichero, datos, nfilas, ncolumnas);
	}
	
	return estado;

		
}


Imagen Imagen::plano(int k){
	Imagen img(nfilas,ncolumnas);
	int tam=(nfilas*ncolumnas);
	byte aux;
	bool estado;	
			
	//Vamos recorriendo los pixeles y accediendo a cada uno de los bytes.
	for(int i=0;i<tam;i++){
		aux=datos[i];//Hacemos una copia para no modificar el nuestro propio
		estado=getbit(aux, k);
		apagar(aux);//Dejamos todos los bits del pixel i a cero
		
		if(estado){
			on(aux,7);//excepto el k-esimo activado
		}

		img.setPos(i,aux);//lo vamos guardando en nuestro nuevo objeto imagen
	}
	
	return img;// Lo devolvemos.
			
}


bool Imagen::aArteASCII(const char grises[], char arteASCII[], int maxlong){
int pos=0,pos1=0;
int Ncaracteres_ASCII=strlen(grises);
bool control=false;

if(maxlong<=(nfilas*(ncolumnas+1)+2)){
	for(int fil=0;fil<nfilas;fil++){
		for(int col=0;col<ncolumnas;col++){
			pos=fil*ncolumnas+col;
			
			if(pos <= maxlong){
				pos1=((get(fil,col)*Ncaracteres_ASCII)/256);
				if(pos1<=Ncaracteres_ASCII){
					arteASCII[pos]=grises[pos1];				
				}else{
						return false;
					}
			}else {
					return false;
			}
		}
			arteASCII[pos++]='\n';
			
	}
}


if(pos<(nfilas*(ncolumnas+1)+2)){
	arteASCII[pos++]='\0';
	control=true;
}


return control;


}



bool Imagen::listaAArteASCII(const Lista &celdas){
	int tam_array=(nfilas*(ncolumnas+1))+2;	
	char * arteASCII=new char[tam_array];
	char cadena_grises[100];
	ofstream arch_salida;
	bool control=false;
	
	
	//Llamaremos desde aqui a aArteASCII();
	for(int i=0;i<celdas.longitud();i++){
		strcpy(cadena_grises, ((celdas.getCelda(i)).c_str()));
		if(aArteASCII(cadena_grises, arteASCII,tam_array)){	
			arch_salida.open("asscii"+to_string(i+1)+".txt");
			if(arch_salida){
				arch_salida<<arteASCII;
				control=true;
			}
			arch_salida.close();
			
		}
		
	}
	
	delete [] arteASCII;//Libero la memoria
	return control;
}




