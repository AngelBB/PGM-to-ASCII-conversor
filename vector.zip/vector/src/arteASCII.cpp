/**
  * @file 
  * @brief Convierte la imagen en ASCII
  **/
//lee imagenes/gio.pgm y la convierte en ascii con los caracteres "@%#*+=-:. "
#include "imagen.h"
#include <iostream>
#include <string>
#include <cstring>
#include <fstream>

using namespace std;

int main(){
	char grises[100];
    char arteASCII[4501]; // 4500 + el \0
    char nombreArchivo[500];
    string nombreImagen,ficheroCadenas,ficheroSalida,grises_str;
    int lineas;
	Imagen origen;
	ifstream fentrada;
	ofstream fsalida;  
      
    
    //Nombre de la imagen a convertir	
	cout << "Imagen de entrada: ";
	cin >> nombreArchivo;
    
    //Pedimos el nombre del fichero txt que contenga las cadenas
	cout<<"Fichero de cadenas: ";
	cin>> ficheroCadenas;
	
	//Pedimos el nombre del fichero/s de salida
	cout<<"Fichero de salida: ";
	cin>> ficheroSalida;
	
		
	/************************************
	Leemos la imagen y creamos el objeto
	*************************************/
	origen.leerImagen(nombreArchivo);
		
	
	/*********************************************************
	Extraer cadena de grises y generar arte ASCII en ficheros
	**********************************************************/
	fentrada.open(ficheroCadenas);	
	if(fentrada){
		getline(fentrada,grises_str); //la primera linea se ignora
		fentrada >> lineas; //leo el numero de datos de grises
		getline(fentrada,grises_str); //leer salto de linea
		if(fentrada){
			int i = 0;
			getline(fentrada,grises_str); //leer cadena de caracteres
			while ((i < lineas)&&(fentrada)){
				if (grises_str != ""){
					strcpy(grises, grises_str.c_str());
					i++;
					origen.aArteASCII(grises,arteASCII,(origen.columnas()*origen.filas()));
					fsalida.open((ficheroSalida+to_string(i)+".txt"));
					if(fsalida){
						fsalida<<arteASCII;
					}
					fsalida.close();
								
				}
				getline(fentrada,grises_str); //leer cadena de caracteres
			}//while
		}
		fentrada.close();
	}else{
			cerr<<"Error leyendo: "<<ficheroCadenas<<endl;
			return 1;
	}
		
	return 0;
}
